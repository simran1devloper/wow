// src/commands.ts
import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';

export async function executeBackendCommands(commands: any[]) {
  for (const cmd of commands) {
    const filePath = vscode.Uri.file(path.join(vscode.workspace.rootPath || '', cmd.path));

    if (cmd.action === 'create_file') {
      await vscode.workspace.fs.writeFile(filePath, Buffer.from(cmd.content || '', 'utf8'));
    }

    if (cmd.action === 'edit_file') {
      const document = await vscode.workspace.openTextDocument(filePath);
      const edit = new vscode.WorkspaceEdit();

      const fullText = document.getText();
      const newText = fullText.replace(cmd.replace.from, cmd.replace.to);
      edit.replace(filePath, new vscode.Range(0, 0, document.lineCount, 0), newText);

      await vscode.workspace.applyEdit(edit);
      await document.save();
    }

    if (cmd.action === 'delete_file') {
      await vscode.workspace.fs.delete(filePath);
    }
  }
}
