// src/context.ts
import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';

export async function getProjectContext() {
  const workspaceFolders = vscode.workspace.workspaceFolders;
  if (!workspaceFolders) return { structure: [], open_files: [], full_files: {} };

  const rootPath = workspaceFolders[0].uri.fsPath;

  function getStructure(dir: string): any[] {
    const entries = fs.readdirSync(dir);
    return entries.map(entry => {
      const fullPath = path.join(dir, entry);
      const stat = fs.statSync(fullPath);
      return stat.isDirectory()
        ? { type: 'folder', name: entry, children: getStructure(fullPath) }
        : { type: 'file', name: entry };
    });
  }

  const openFiles = vscode.workspace.textDocuments.map(doc => ({
    fileName: doc.fileName,
    content: doc.getText()
  }));

  const fullFiles: { [key: string]: string } = {};
  const readFiles = (dir: string) => {
    const entries = fs.readdirSync(dir);
    for (const entry of entries) {
      const fullPath = path.join(dir, entry);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        readFiles(fullPath);
      } else {
        try {
          const content = fs.readFileSync(fullPath, 'utf8');
          fullFiles[fullPath] = content;
        } catch {}
      }
    }
  };
  readFiles(rootPath);

  return {
    structure: getStructure(rootPath),
    open_files: openFiles,
    full_files: fullFiles
  };
}
