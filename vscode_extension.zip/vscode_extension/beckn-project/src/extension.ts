import * as vscode from 'vscode';
import { getProjectContext } from './context';
import { executeBackendCommands } from './commands';
import { getWebviewContent } from './panel/webview';

interface UserPromptMessage {
  command: 'userPrompt';
  text: string;
}

interface BotReplyMessage {
  command: 'botReply';
  messages: string[];
}

interface BackendResponse {
  messages: string[];
  commands?: string[];
}

export function activate(context: vscode.ExtensionContext): void {
  const disposable = vscode.commands.registerCommand('aiChat.start', () => {
    const panel = vscode.window.createWebviewPanel(
      'aiChat',
      'AI Assistant',
      vscode.ViewColumn.One,
      { enableScripts: true }
    );

    panel.webview.html = getWebviewContent();

    panel.webview.onDidReceiveMessage(async (message: UserPromptMessage) => {
      try {
        if (message.command === 'userPrompt') {
          const contextObj = await getProjectContext();
          const contextData = JSON.stringify(contextObj);

          const response = await fetch('http://localhost:8000/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              user_prompt: message.text,
              project_context: contextData
            })
          });

          const data = await response.json() as BackendResponse;

          if (data.commands && data.commands.length > 0) {
            await executeBackendCommands(data.commands);
          }

          const replyMessage: BotReplyMessage = {
            command: 'botReply',
            messages: data.messages
          };

          panel.webview.postMessage(replyMessage);
        }
      } catch (err: any) {
        console.error('Extension error:', err);
        vscode.window.showErrorMessage(`Error: ${err.message || err}`);
      }
    });
  });

  context.subscriptions.push(disposable);
}

export function deactivate(): void {}
