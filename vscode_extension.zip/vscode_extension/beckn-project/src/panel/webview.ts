// src/panel/webview.ts
export function getWebviewContent(): string {
  return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: sans-serif; padding: 1em; }
        .chatbox { height: 300px; overflow-y: scroll; border: 1px solid #ccc; padding: 10px; }
        .message { margin: 5px 0; }
        input { width: 80%; padding: 8px; }
        button { padding: 8px; }
      </style>
    </head>
    <body>
      <h2>AI Chat Assistant</h2>
      <div class="chatbox" id="chat"></div>
      <input id="prompt" placeholder="Ask something..." />
      <button onclick="send()">Send</button>

      <script>
        const vscode = acquireVsCodeApi();

        function appendMessage(role, text) {
          const el = document.createElement('div');
          el.className = 'message';
          el.innerHTML = '<strong>' + role + ':</strong> ' + text;
          document.getElementById('chat').appendChild(el);
        }

        function send() {
          const input = document.getElementById('prompt');
          const text = input.value;
          appendMessage('You', text);
          vscode.postMessage({ command: 'userPrompt', text });
          input.value = '';
        }

        window.addEventListener('message', event => {
          const data = event.data;
          if (data.command === 'botReply') {
            data.messages.forEach(msg => appendMessage('AI', msg));
          }
        });
      </script>
    </body>
    </html>
  `;
}
